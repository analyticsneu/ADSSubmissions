﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
	public partial class Home : System.Web.UI.Page
	{
		MnistHandwritingRecognitionClass c=new MnistHandwritingRecognitionClass();
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		//protected void ClearValues_Click(object sender, EventArgs e)
		//{
		//	uploadedImage.Visible = false;
		//}
		//protected void UploadButton_Click(object sender, EventArgs e)
		//{
		//	if (FileUpload1.HasFile)
		//		try
		//		{
		//			FileUpload1.SaveAs(Server.MapPath("~/uploads/") +
		//				 FileUpload1.FileName);

		//			String fileName = FileUpload1.PostedFile.FileName;
		//			var filePath = Path.Combine(Server.MapPath("~/uploads"), fileName);
					
		//			uploadedImage.ImageUrl = "~/uploads/" + FileUpload1.FileName; //filePath;
		//			uploadedImage.Visible = true;
		//			if (!string.IsNullOrEmpty(filePath))
		//			{
		//				c.FilePath = filePath;
		//				String strbuild = c.IdentifyImage();
		//				FileUploadedLabel.Text = "Character in uploaded image is " + strbuild;
		//			}
		//		}
		//		catch (Exception ex)
		//		{
		//			FileUploadedLabel.Text = "ERROR: " + ex.Message;
		//		}
		//	else
		//	{
		//		FileUploadedLabel.Text = "You have not specified a file.";
		//	}
		//}

	}
}