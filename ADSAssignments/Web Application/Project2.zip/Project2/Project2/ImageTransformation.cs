﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Web;

namespace Project2
{
	public class ImageTransformation
	{
		public String[] TransformaImagemEmArray(String filePath)
		{
			// Transforma a imagem de entrada em um array de doubles
			// com os valores grayscale da imagem
			String[] image1D=new string[401];
			using (Bitmap imagem = (Bitmap) Image.FromFile(filePath))
			{
				//Bitmap imagem;
				if (imagem.Height > 20 || imagem.Width > 20)
				{
					image1D = ScaleImage(imagem, 20, 20);
					return image1D;
				}
				
				BitmapData bitmap_data = imagem.LockBits(new Rectangle(0, 0, imagem.Height, imagem.Width),
					ImageLockMode.ReadOnly, imagem.PixelFormat);

				int pixelsize = Image.GetPixelFormatSize(bitmap_data.PixelFormat)/8;

				IntPtr pointer = bitmap_data.Scan0;
				int nbytes = bitmap_data.Height*bitmap_data.Stride;
				byte[] imagebytes = new byte[nbytes];
				System.Runtime.InteropServices.Marshal.Copy(pointer, imagebytes, 0, nbytes);

				double red;
				double green;
				double blue;
				double gray;

				var _grayscale_array = new Double[bitmap_data.Height, bitmap_data.Width];

				if (pixelsize >= 3)
				{
					for (int I = 0; I < bitmap_data.Height; I++)
					{
						for (int J = 0; J < bitmap_data.Width; J++)
						{
							int position = (I*bitmap_data.Stride) + (J*pixelsize);
							blue = imagebytes[position];
							green = imagebytes[position + 1];
							red = imagebytes[position + 2];
							gray = 0.299*red + 0.587*green + 0.114*blue;
							_grayscale_array[I, J] = gray;
						}
					}
				}

				imagem.UnlockBits(bitmap_data);
				image1D = ConvertToARow(_grayscale_array);
				return image1D;
			}
		}

		public static String[] ConvertToARow(double[,] bitmapMatrix)
		{
			String[] image1D = new String[401];
			image1D[0] = "0";
			int count = 1;
			for (int i = 0; i < 20; i++)
			{
				for (int j = 0; j < 20; j++)
				{
					image1D[count] = bitmapMatrix[i, j].ToString();
					count++;
				}
			}
			return image1D;
		}

		public static String[] ScaleImage(Image image, int maxWidth, int maxHeight)
		{
			
			var imagem = new Bitmap(maxWidth, maxHeight);

			using (var graphics = Graphics.FromImage(imagem))
			{
				graphics.DrawImage(image, 0, 0, maxWidth, maxHeight);
				BitmapData bitmap_data = imagem.LockBits(new Rectangle(0, 0, imagem.Height, imagem.Width),
				ImageLockMode.ReadOnly, imagem.PixelFormat);

				int pixelsize =Image.GetPixelFormatSize(bitmap_data.PixelFormat) / 8;

				IntPtr pointer = bitmap_data.Scan0;
				int nbytes = bitmap_data.Height * bitmap_data.Stride;
				byte[] imagebytes = new byte[nbytes];
				System.Runtime.InteropServices.Marshal.Copy(pointer, imagebytes, 0, nbytes);

				double red;
				double green;
				double blue;
				double gray;

				var _grayscale_array = new Double[bitmap_data.Height, bitmap_data.Width];

				if (pixelsize >= 3)
				{
					for (int I = 0; I < bitmap_data.Height; I++)
					{
						for (int J = 0; J < bitmap_data.Width; J++)
						{
							int position = (I * bitmap_data.Stride) + (J * pixelsize);
							blue = imagebytes[position];
							green = imagebytes[position + 1];
							red = imagebytes[position + 2];
							gray = 0.299 * red + 0.587 * green + 0.114 * blue;
							_grayscale_array[I, J] = gray;
						}
					}
				}

				imagem.UnlockBits(bitmap_data);
				String[] image1D = ConvertToARow(_grayscale_array);
				return image1D;

			}

			
		}

		public String[,] TransformaImagemToMatrix(String filePath)
		{
			// Transforma a imagem de entrada em um array de doubles
			// com os valores grayscale da imagem

			using (Bitmap imagem =(Bitmap) Image.FromFile(filePath))
			{
				if (imagem.Height > 20 || imagem.Width > 20)
				{
					String[,] image1D = ScaleImage2(imagem, 20, 20);
					return image1D;
				}

				BitmapData bitmap_data = imagem.LockBits(new System.Drawing.Rectangle(0, 0, imagem.Height, imagem.Width),
					ImageLockMode.ReadOnly, imagem.PixelFormat);

				int pixelsize = System.Drawing.Image.GetPixelFormatSize(bitmap_data.PixelFormat)/8;

				IntPtr pointer = bitmap_data.Scan0;
				int nbytes = bitmap_data.Height*bitmap_data.Stride;
				byte[] imagebytes = new byte[nbytes];
				System.Runtime.InteropServices.Marshal.Copy(pointer, imagebytes, 0, nbytes);

				double red;
				double green;
				double blue;
				double gray;

				var _grayscale_array = new Double[bitmap_data.Height, bitmap_data.Width];
				String[,] greyScaleMatrix = new string[bitmap_data.Height, bitmap_data.Width];
				if (pixelsize >= 3)
				{
					for (int I = 0; I < bitmap_data.Height; I++)
					{
						for (int J = 0; J < bitmap_data.Width; J++)
						{
							int position = (I*bitmap_data.Stride) + (J*pixelsize);
							blue = imagebytes[position];
							green = imagebytes[position + 1];
							red = imagebytes[position + 2];
							gray = 0.299*red + 0.587*green + 0.114*blue;
							_grayscale_array[I, J] = gray;
							greyScaleMatrix[I, J] = gray.ToString();
						}
					}
				}

				imagem.UnlockBits(bitmap_data);

				return greyScaleMatrix;
			}
		}

		public static String[,] ScaleImage2(Image image, int maxWidth, int maxHeight)
		{

			var imagem = new Bitmap(maxWidth, maxHeight);

			using (var graphics = Graphics.FromImage(imagem))
			{
				graphics.DrawImage(image, 0, 0, maxWidth, maxHeight);
				BitmapData bitmap_data = imagem.LockBits(new Rectangle(0, 0, imagem.Height, imagem.Width),
				ImageLockMode.ReadOnly, imagem.PixelFormat);

				int pixelsize = Image.GetPixelFormatSize(bitmap_data.PixelFormat) / 8;

				IntPtr pointer = bitmap_data.Scan0;
				int nbytes = bitmap_data.Height * bitmap_data.Stride;
				byte[] imagebytes = new byte[nbytes];
				System.Runtime.InteropServices.Marshal.Copy(pointer, imagebytes, 0, nbytes);

				double red;
				double green;
				double blue;
				double gray;

				var _grayscale_array = new String[bitmap_data.Height, bitmap_data.Width];
				
				if (pixelsize >= 3)
				{
					for (int I = 0; I < bitmap_data.Height; I++)
					{
						for (int J = 0; J < bitmap_data.Width; J++)
						{
							int position = (I * bitmap_data.Stride) + (J * pixelsize);
							blue = imagebytes[position];
							green = imagebytes[position + 1];
							red = imagebytes[position + 2];
							gray = 0.299 * red + 0.587 * green + 0.114 * blue;
							_grayscale_array[I, J] = gray.ToString();
						}
					}
				}

				imagem.UnlockBits(bitmap_data);
				//String[] image1D = ConvertToARow(_grayscale_array);
				return _grayscale_array;

			}


		}

	}
}