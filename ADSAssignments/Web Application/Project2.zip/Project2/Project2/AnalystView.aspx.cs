﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
	public partial class AnalystView : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void ViewMatrix_Click(object sender, EventArgs e)
		{
			ImageTransformation it = new ImageTransformation();
			String[,] matrix = new String[20, 20];
			if (FileUpload1.HasFile)
				try
				{
					FileUpload1.SaveAs(Server.MapPath("~/uploads/") +
						 FileUpload1.FileName);
					String fileName = FileUpload1.PostedFile.FileName;
					var filePath = Path.Combine(Server.MapPath("~/uploads"), fileName);
					FileUploadedLabel.Text = "File name: " +
						 fileName + "<br>" +
						 FileUpload1.PostedFile.ContentLength + " kb<br>" +
						 "Content type: " + FileUpload1.PostedFile.ContentType;
					uploadedImage.ImageUrl = "~/uploads/" + FileUpload1.FileName; //filePath;
					uploadedImage.Visible = true;
					if (!string.IsNullOrEmpty(filePath))
					{
						matrix = it.TransformaImagemToMatrix(filePath);
					}
				}
				catch (Exception ex)
				{
					FileUploadedLabel.Text = "ERROR: " + ex.Message;
				}
			else
			{
				FileUploadedLabel.Text = "You have not specified a file.";
			}

		}
		protected void ServerButton_Click(object sender, EventArgs e)
		{

			GridView gdv = new GridView();
			ImageTransformation it = new ImageTransformation();
			String[,] matrix = new String[20, 20];
			if (FileUpload1.HasFile)
				try
				{

					String folderPath = Server.MapPath("~/uploads");
					if (!Directory.Exists(folderPath))
					{
						Directory.CreateDirectory(folderPath);
					}
					FileUpload1.SaveAs(folderPath +
						 FileUpload1.FileName);
					String fileName = FileUpload1.PostedFile.FileName;
					var filePath = Path.Combine(folderPath, fileName);

					uploadedImage.ImageUrl = "~/uploads/" + FileUpload1.FileName; //filePath;
					uploadedImage.Visible = true;
					if (!string.IsNullOrEmpty(filePath))
					{
						String[] t2 = new String[20];
						matrix = it.TransformaImagemToMatrix(filePath);

						DataTable dt = new DataTable();
						DataRow dr = null;
						for (int i = 0; i < 20; i++)
						{
							dt.Columns.Add(new DataColumn(i.ToString(), typeof(string)));

						}
						for (int i = 0; i < 20; i++)
						{
							dr = dt.NewRow();
							for (int j = 0; j < 20; j++)
							{
								dr[j.ToString()] = matrix[i, j];
							}
							dt.Rows.Add(dr);
						}
						gdv.DataSource = dt;
						gdv.DataBind();
						ModalPanel.Controls.Add(gdv);
						OKButton.Visible = true;
					}
				}
				catch (Exception ex)
				{
					FileUploadedLabel.Text = "ERROR: " + ex.Message;
				}
			
			else
			{
				FileUploadedLabel.Text = "You have not specified a file.";
			}

			ClientScript.RegisterStartupScript(this.GetType(), "key", "launchModal();", true);
		}

		protected void OKButton_Click(object sender, EventArgs e)
		{
			OKButton.Visible = false;
		}
	}
}