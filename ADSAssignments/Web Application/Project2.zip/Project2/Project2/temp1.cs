﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;

namespace Project2
{
	public class temp1
	{
		public String[] TransformaImagemEmArray(String filePath)
		{
			// Transforma a imagem de entrada em um array de doubles
			// com os valores grayscale da imagem
			String[] image1D = new string[785];
			using (Bitmap imagem = (Bitmap)Image.FromFile(filePath))
			{
				//Bitmap imagem;
				if (imagem.Height > 28 || imagem.Width > 28)
				{
					image1D = ScaleImage(imagem, 28, 28);
					return image1D;
				}

				using (var ms = new MemoryStream())
				{
					imagem.Save(ms, ImageFormat.Gif);
					var x= ms.ToArray();
					for (int i = 0; i < 785; i++)
					{
						image1D[i] = x[i].ToString();
					}
					return image1D;
				}
				
				
			}
		}
		public static String[] ConvertToARow(double[,] bitmapMatrix)
		{
			String[] image1D = new String[785];
			image1D[0] = "0";
			int count = 1;
			for (int i = 0; i < 28; i++)
			{
				for (int j = 0; j < 28; j++)
				{
					image1D[count] = bitmapMatrix[i, j].ToString();
					count++;
				}
			}
			return image1D;
		}
		public static String[] ScaleImage(Image image, int maxWidth, int maxHeight)
		{

			var imagem = new Bitmap(maxWidth, maxHeight);
			String[] image1D = new String[785];
			using (var graphics = Graphics.FromImage(imagem))
			{
				graphics.DrawImage(image, 0, 0, maxWidth, maxHeight);
				using (var ms = new MemoryStream())
				{
					imagem.Save(ms, ImageFormat.Gif);
					var x = ms.ToArray();
					for (int i = 0; i < 785; i++)
					{
						image1D[i] = x[i].ToString();
					}
					return image1D;
				}
				
				return image1D;

			}


		}

	}
}