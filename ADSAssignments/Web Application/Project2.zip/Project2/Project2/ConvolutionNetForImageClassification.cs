﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Project2
{
	public class ConvolutionNetForImageClassification
	{
		public class StringTable
		{
			public string[] ColumnNames { get; set; }
			public string[,] Values { get; set; }
		}

		public char Result;
		public String FilePath;
		public String[] iamge1D;
		ImageTransformation imageTransformer = new ImageTransformation();
		public ConvolutionNetForImageClassification()
		{
			Result = 'a';
			iamge1D=new string[401];
			//	FilePath = "c:\\users\\rmagar\\documents\\visual studio 2013\\Projects\\WebApplication1\\WebApplication1\\uploads\\6284.Bmp";
		}

		public char IdentifyImage()
		{
			iamge1D = imageTransformer.TransformaImagemEmArray(FilePath);
			InvokeRequestResponseService().Wait();
			return Result;
		}
		async Task InvokeRequestResponseService()
		{
			
			 
			using (var client = new HttpClient())
			{
				String[,] tempValue = new string[1, 401];

				for (int i = 0; i < 401; i++)
				{
					tempValue[0, i] = iamge1D[i];
				}
				var scoreRequest = new
				{

					Inputs = new Dictionary<string, StringTable>() { 
                        { 
                            "input1", 
                            new StringTable() 
                            {
                                ColumnNames = new string[] {"Label", "Column2", "Column3", "Column4", "Column5", "Column6", "Column7", "Column8", "Column9", "Column10", "Column11", "Column12", "Column13", "Column14", "Column15", "Column16", "Column17", "Column18", "Column19", "Column20", "Column21", "Column22", "Column23", "Column24", "Column25", "Column26", "Column27", "Column28", "Column29", "Column30", "Column31", "Column32", "Column33", "Column34", "Column35", "Column36", "Column37", "Column38", "Column39", "Column40", "Column41", "Column42", "Column43", "Column44", "Column45", "Column46", "Column47", "Column48", "Column49", "Column50", "Column51", "Column52", "Column53", "Column54", "Column55", "Column56", "Column57", "Column58", "Column59", "Column60", "Column61", "Column62", "Column63", "Column64", "Column65", "Column66", "Column67", "Column68", "Column69", "Column70", "Column71", "Column72", "Column73", "Column74", "Column75", "Column76", "Column77", "Column78", "Column79", "Column80", "Column81", "Column82", "Column83", "Column84", "Column85", "Column86", "Column87", "Column88", "Column89", "Column90", "Column91", "Column92", "Column93", "Column94", "Column95", "Column96", "Column97", "Column98", "Column99", "Column100", "Column101", "Column102", "Column103", "Column104", "Column105", "Column106", "Column107", "Column108", "Column109", "Column110", "Column111", "Column112", "Column113", "Column114", "Column115", "Column116", "Column117", "Column118", "Column119", "Column120", "Column121", "Column122", "Column123", "Column124", "Column125", "Column126", "Column127", "Column128", "Column129", "Column130", "Column131", "Column132", "Column133", "Column134", "Column135", "Column136", "Column137", "Column138", "Column139", "Column140", "Column141", "Column142", "Column143", "Column144", "Column145", "Column146", "Column147", "Column148", "Column149", "Column150", "Column151", "Column152", "Column153", "Column154", "Column155", "Column156", "Column157", "Column158", "Column159", "Column160", "Column161", "Column162", "Column163", "Column164", "Column165", "Column166", "Column167", "Column168", "Column169", "Column170", "Column171", "Column172", "Column173", "Column174", "Column175", "Column176", "Column177", "Column178", "Column179", "Column180", "Column181", "Column182", "Column183", "Column184", "Column185", "Column186", "Column187", "Column188", "Column189", "Column190", "Column191", "Column192", "Column193", "Column194", "Column195", "Column196", "Column197", "Column198", "Column199", "Column200", "Column201", "Column202", "Column203", "Column204", "Column205", "Column206", "Column207", "Column208", "Column209", "Column210", "Column211", "Column212", "Column213", "Column214", "Column215", "Column216", "Column217", "Column218", "Column219", "Column220", "Column221", "Column222", "Column223", "Column224", "Column225", "Column226", "Column227", "Column228", "Column229", "Column230", "Column231", "Column232", "Column233", "Column234", "Column235", "Column236", "Column237", "Column238", "Column239", "Column240", "Column241", "Column242", "Column243", "Column244", "Column245", "Column246", "Column247", "Column248", "Column249", "Column250", "Column251", "Column252", "Column253", "Column254", "Column255", "Column256", "Column257", "Column258", "Column259", "Column260", "Column261", "Column262", "Column263", "Column264", "Column265", "Column266", "Column267", "Column268", "Column269", "Column270", "Column271", "Column272", "Column273", "Column274", "Column275", "Column276", "Column277", "Column278", "Column279", "Column280", "Column281", "Column282", "Column283", "Column284", "Column285", "Column286", "Column287", "Column288", "Column289", "Column290", "Column291", "Column292", "Column293", "Column294", "Column295", "Column296", "Column297", "Column298", "Column299", "Column300", "Column301", "Column302", "Column303", "Column304", "Column305", "Column306", "Column307", "Column308", "Column309", "Column310", "Column311", "Column312", "Column313", "Column314", "Column315", "Column316", "Column317", "Column318", "Column319", "Column320", "Column321", "Column322", "Column323", "Column324", "Column325", "Column326", "Column327", "Column328", "Column329", "Column330", "Column331", "Column332", "Column333", "Column334", "Column335", "Column336", "Column337", "Column338", "Column339", "Column340", "Column341", "Column342", "Column343", "Column344", "Column345", "Column346", "Column347", "Column348", "Column349", "Column350", "Column351", "Column352", "Column353", "Column354", "Column355", "Column356", "Column357", "Column358", "Column359", "Column360", "Column361", "Column362", "Column363", "Column364", "Column365", "Column366", "Column367", "Column368", "Column369", "Column370", "Column371", "Column372", "Column373", "Column374", "Column375", "Column376", "Column377", "Column378", "Column379", "Column380", "Column381", "Column382", "Column383", "Column384", "Column385", "Column386", "Column387", "Column388", "Column389", "Column390", "Column391", "Column392", "Column393", "Column394", "Column395", "Column396", "Column397", "Column398", "Column399", "Column400", "Column401"},
                                Values = tempValue
                            }
                        },
                    },
					GlobalParameters = new Dictionary<string, string>()
					{
					}
				};
				const string apiKey = "ld6bEBJsxTpGAcO/zfGk0UNlnYyW0hRX+a96UjE4x0PtRCBMuQ/jqlAN3BY+kkWrihxsdZ3M77sjf99E8zh+Rw=="; // Replace this with the API key for the web service
				client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

				client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/31d9db27999b494dbd64b2c3da00fe6d/services/cbc1544f8ebd4b14baa14caba1170ec1/execute?api-version=2.0&details=true");

				// WARNING: The 'await' statement below can result in a deadlock if you are calling this code from the UI thread of an ASP.Net application.
				// One way to address this would be to call ConfigureAwait(false) so that the execution does not attempt to resume on the original context.
				// For instance, replace code such as:
				//      result = await DoSomeTask()
				// with the following:
				//      result = await DoSomeTask().ConfigureAwait(false)


				HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest).ConfigureAwait(false);

				if (response.IsSuccessStatusCode)
				{
					string result = await response.Content.ReadAsStringAsync();
					Console.WriteLine("Result: {0}", result);
					JObject jObject = JsonConvert.DeserializeObject<JObject>(result);

					String temp= jObject["Results"]["output1"]["value"]["Values"][0][463].ToString();
					int rr = Int32.Parse(temp);
					char c = Convert.ToChar(rr);
					Result = c;
				}
				else
				{
					Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

					// Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
					Console.WriteLine(response.Headers.ToString());

					string responseContent = await response.Content.ReadAsStringAsync();
					Console.WriteLine(responseContent);
				}
			}

		}
	}

}